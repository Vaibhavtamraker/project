package in.matman.service.controller;

import in.matman.service.entity.Project;
import in.matman.service.entity.ProjectDto;
import in.matman.service.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/project")
public class ProjectController {

  private final ProjectService projectService;

  @Autowired
  public ProjectController(ProjectService projectService) {
    this.projectService = projectService;
  }

  @GetMapping("/find-all")
  public List<Project> all() {
    return projectService.findAll();
  }

  @PostMapping("/create")
  public Project create(@RequestBody ProjectDto projectDto) {
    return projectService.create(projectDto);
  }

  @PutMapping("/{id}/update")
  public Project update(@PathVariable Long id, @RequestBody ProjectDto projectDto) {
    return projectService.update(id, projectDto);
  }

  @DeleteMapping("/{id}/delete")
  public void delete(@PathVariable Long id) {
    projectService.delete(id);
  }

}
