package in.matman.service.service;

import in.matman.service.entity.ItemRequirement;
import in.matman.service.entity.ItemRequirementDto;
import in.matman.service.repository.ItemRepository;
import in.matman.service.repository.ItemRequirementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ItemRequirementServiceImpl implements ItemRequirementService {

  private final ItemRequirementRepository itemRequirementRepository;
  private final ItemRepository itemRepository;

  @Autowired
  public ItemRequirementServiceImpl(ItemRequirementRepository itemRequirementRepository, ItemRepository itemRepository) {
    this.itemRequirementRepository = itemRequirementRepository;
    this.itemRepository = itemRepository;
  }

  @Override
  public List<ItemRequirement> findAll() {
    return itemRequirementRepository.findAll();
  }

  @Override
  public List<ItemRequirement> create(List<ItemRequirementDto> itemRequirementDtos) {
    return itemRequirementRepository.saveAll(itemRequirementDtos.stream().map(itemRequirementDto -> {
      ItemRequirement itemRequirement = new ItemRequirement();
      itemRequirement.setItem(itemRepository.findById(itemRequirementDto.getItemId()).orElse(null));
      itemRequirement.setQuantity(itemRequirementDto.getQuantity());
      return itemRequirement;
    }).collect(Collectors.toSet()));
  }

  @Override
  public ItemRequirement update(Long id, ItemRequirementDto itemRequirementDto) {
    Optional<ItemRequirement> itemRequirementOptional = itemRequirementRepository.findById(id);
    if (itemRequirementOptional.isPresent()) {
      ItemRequirement itemRequirement = itemRequirementOptional.get();
      if (!itemRequirement.isProcessed()) {
        if (itemRequirementDto.getItemId() != null) {
          itemRepository.findById(itemRequirementDto.getItemId()).ifPresent(itemRequirement::setItem);
        }
        if (itemRequirementDto.getQuantity() != null) {
          itemRequirement.setQuantity(itemRequirementDto.getQuantity());
        }
        return itemRequirementRepository.save(itemRequirement);
      }
    }
    return null;
  }

  @Override
  public void delete(Long id) {
    itemRequirementRepository.deleteById(id);
  }

}
