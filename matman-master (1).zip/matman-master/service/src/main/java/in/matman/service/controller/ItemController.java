package in.matman.service.controller;

import in.matman.service.entity.Item;
import in.matman.service.entity.ItemDto;
import in.matman.service.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/item")
public class ItemController {

  private final ItemService itemService;

  @Autowired
  public ItemController(ItemService itemService) {
    this.itemService = itemService;
  }

  //	for find all
  @GetMapping("/find-all")
  public List<Item> findAll() {
    return itemService.findAll();
  }

  //	for findbyid
  @GetMapping("/{id}")
  public Item one(@PathVariable Long id) {
    return itemService.findById(id);
  }

  //for creating new item
  @PostMapping("/create")
  public Item create(@RequestBody ItemDto itemDto) {
    return itemService.create(itemDto);
  }

  //for updating
  @PutMapping("/{id}/update")
  public Item update(@RequestBody ItemDto itemDto, @PathVariable Long id) {
    return itemService.update(itemDto, id);
  }

  @DeleteMapping("/{id}/delete")
  public void delete(@PathVariable Long id) {
    itemService.delete(id);
  }
}
