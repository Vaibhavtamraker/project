package in.matman.service.controller;

import in.matman.service.entity.Site;
import in.matman.service.entity.SiteDto;
import in.matman.service.service.SiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/site")
public class SiteController {

  private final SiteService siteService;

  @Autowired
  public SiteController(SiteService siteService) {
    this.siteService = siteService;
  }

  @GetMapping("/find-all")
  public List<Site> all() {
    return siteService.findAll();
  }

  @PostMapping("/create")
  public Site create(@RequestBody SiteDto siteDto) {
    return siteService.create(siteDto);
  }

  @PutMapping("/{id}/update")
  public Site update(@PathVariable Long id, @RequestBody SiteDto siteDto) {
    return siteService.update(id, siteDto);
  }

  @DeleteMapping("/{id}/delete")
  public void delete(@PathVariable Long id) {
    siteService.delete(id);
  }

}
