package in.matman.service.service;

import in.matman.service.entity.Warehouse;
import in.matman.service.repository.UserRepository;
import in.matman.service.repository.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WarehouseServiceImpl implements WarehouseService {

  private final WarehouseRepository warehouseRepository;
  private final UserRepository userRepository;

  @Autowired
  public WarehouseServiceImpl(WarehouseRepository warehouseRepository, UserRepository userRepository, WarehouseRepository warehouseLocationRepository) {
    this.warehouseRepository = warehouseRepository;
    this.userRepository = userRepository;
  }

  @Override
  public List<Warehouse> findAll() {
    return warehouseRepository.findAll();
  }

  @Override
  public Warehouse create(Warehouse warehouse) {
    return warehouseRepository.save(warehouse);
  }

  @Override
  public Warehouse update(Long id, Warehouse warehouse) {
    warehouse.setId(id);
    return warehouseRepository.save(warehouse);
  }

  @Override
  public void delete(Long id) {
    warehouseRepository.deleteById(id);
  }

}
