package in.matman.service.controller;

import java.util.List;

import in.matman.service.entity.VendorDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.matman.service.entity.Vendor;

import in.matman.service.service.VendorService;

@RestController
@RequestMapping("/api/v1/vendor")
public class VendorController {

  private final VendorService vendorService;

  @Autowired
  public VendorController(VendorService vendorService) {
    this.vendorService = vendorService;
  }

  @GetMapping("/find-all")
  public List<Vendor> findAll() {
    return vendorService.findAll();
  }

  @GetMapping("/{id}")
  public Vendor one(@PathVariable Long id) {
    return vendorService.findById(id);
  }

  @PostMapping("/create")
  public Vendor create(@RequestBody VendorDto vendorDto) {
    return vendorService.create(vendorDto);
  }

  @PutMapping("/{id}")
  public Vendor update(@RequestBody VendorDto vendorDto, @PathVariable Long id) {
    return vendorService.update(vendorDto, id);
  }

  @DeleteMapping("/{id}/delete")
  public void delete(@PathVariable Long id) {
    vendorService.delete(id);
  }


}
