package in.matman.service.service;

import java.util.List;

import in.matman.service.entity.Uom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.matman.service.repository.UomRepository;

@Service
@Transactional
public class UomService {

  private final UomRepository uomRepository;

  @Autowired
  public UomService(UomRepository uomRepository) {
    this.uomRepository = uomRepository;
  }

  public List<Uom> findAll() {
    return uomRepository.findAll();
  }

  public Uom findById(Long id) {
    return uomRepository.findById(id).get();
  }

  public Uom create(Uom uom) {
    return uomRepository.save(uom);
  }

  public Uom update(Uom uomUser, Long id) {
    Uom uomdb = uomRepository.findById(id).get();
    if (uomUser.getName() != null) {
      uomdb.setName(uomUser.getName());
    }
    if (uomUser.getSymbol() != null) {
      uomdb.setSymbol(uomUser.getSymbol());
    }
    return uomRepository.save(uomdb);
  }

  public void delete(Long id) {
    uomRepository.deleteById(id);
  }

}


