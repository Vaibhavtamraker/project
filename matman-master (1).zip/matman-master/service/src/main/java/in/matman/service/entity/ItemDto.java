package in.matman.service.entity;

public class ItemDto {

  private String title;
  private String description;
  private Long uomId;

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Long getUomId() {
    return uomId;
  }

  public void setUomId(Long uomId) {
    this.uomId = uomId;
  }

  public ItemDto() {
  }

  @Override
  public String toString() {
    return "ItemDto{" +
      "title='" + title + '\'' +
      ", description='" + description + '\'' +
      ", uomId=" + uomId +
      '}';
  }

}
