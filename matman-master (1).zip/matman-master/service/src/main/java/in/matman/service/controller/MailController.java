package in.matman.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import in.matman.service.entity.Mail;
import in.matman.service.service.MailService;

@RestController
@RequestMapping("/mail")
public class MailController {
	
	@Autowired
	MailService mailService;

	@GetMapping("/sendmail")
	public void sendEmail() {
		 
        Mail mail = new Mail();
        mail.setMailFrom("matmantest925@gmail.com");
        mail.setMailTo("kchetan171@gmail.com");
        mail.setMailSubject("Testmail");
        mail.setMailContent("www.matman.com");
 
       
        mailService.sendEmail(mail);
 
		
	}
}
