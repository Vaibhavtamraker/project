package in.matman.service.entity;

import java.util.Set;

public class UserDto {

    private String firstName;
    private String lastName;
    private String username;
    private String mobile;
    private String mail;
    private Boolean accountNonLocked;
    private Boolean accountNonExpired;
    private Boolean credentialNonExpired;
    private Boolean enabled;
    private Set<Long> authorityIds;
    
  
    public Boolean getAccountNonLocked() {
		return accountNonLocked;
	}

	public void setAccountNonLocked(Boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	public Boolean getAccountNonExpired() {
		return accountNonExpired;
	}

	public void setAccountNonExpired(Boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	public Boolean getCredentialNonExpired() {
		return credentialNonExpired;
	}

	public void setCredentialNonExpired(Boolean credentialNonExpired) {
		this.credentialNonExpired = credentialNonExpired;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	
    

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public Set<Long> getAuthorityIds() {
        return authorityIds;
    }

    public void setAuthorityIds(Set<Long> authorityIds) {
        this.authorityIds = authorityIds;
    }

    public UserDto() {
    }

}
