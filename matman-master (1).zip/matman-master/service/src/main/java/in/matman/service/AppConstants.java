package in.matman.service;

public class AppConstants {
	  public static final String PASS_CHAR = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	  public static final int MAX_PASS_LEN=8;
}
