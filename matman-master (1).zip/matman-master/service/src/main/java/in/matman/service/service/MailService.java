package in.matman.service.service;

import in.matman.service.entity.Mail;

public interface MailService {
	public void sendEmail(Mail mail);

}
