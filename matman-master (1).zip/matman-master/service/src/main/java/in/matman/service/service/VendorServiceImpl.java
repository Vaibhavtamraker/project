package in.matman.service.service;

import in.matman.service.entity.Vendor;
import in.matman.service.entity.VendorDto;
import in.matman.service.repository.UserRepository;
import in.matman.service.repository.VendorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class VendorServiceImpl implements VendorService {

  private final VendorRepository vendorRepository;
  private final UserRepository userRepository;

  @Autowired
  public VendorServiceImpl(VendorRepository vendorRepository, UserRepository userRepository) {
    this.vendorRepository = vendorRepository;
    this.userRepository = userRepository;
  }

  @Override
  public List<Vendor> findAll() {
    return vendorRepository.findAll();
  }

  @Override
  public Vendor findById(Long id) {
    return vendorRepository.findById(id).orElse(null);
  }

  @Override
  public Vendor create(VendorDto vendorDto) {
    Vendor vendor = new Vendor();
    vendor.setName(vendorDto.getName());
    vendor.setAddress(vendorDto.getAddress());
    vendor.setCity(vendorDto.getCity());
    vendor.setState(vendorDto.getCity());
    vendor.setCountry(vendorDto.getCountry());
    vendor.setPinCode(vendorDto.getPinCode());
    vendor.setContactPersons(userRepository.findAllById(vendorDto.getContactPersonIds()));
    return vendorRepository.save(vendor);
  }

  @Override
  public Vendor update(VendorDto vendorDto, Long id) {
    Optional<Vendor> vendorOptional = vendorRepository.findById(id);
    if (vendorOptional.isPresent()) {
      Vendor vendorDb = vendorOptional.get();
      if (vendorDto.getName() != null) {
        vendorDb.setName(vendorDto.getName());
      }
      if (vendorDto.getAddress() != null) {
        vendorDb.setAddress(vendorDto.getAddress());
      }
      if (vendorDto.getPinCode() != 0L) {
        vendorDb.setPinCode(vendorDto.getPinCode());
      }
      if (vendorDto.getCity() != null) {
        vendorDb.setCity(vendorDto.getCity());
      }
      if (vendorDto.getState() != null) {
        vendorDb.setState(vendorDto.getState());
      }
      if (vendorDto.getCountry() != null) {
        vendorDb.setCountry(vendorDto.getCountry());
      }
      if (vendorDto.getContactPersonIds() != null && vendorDto.getContactPersonIds().size() > 0) {
        vendorDb.setContactPersons(userRepository.findAllById(vendorDto.getContactPersonIds()));
      }
      return vendorRepository.save(vendorDb);
    }
    return null;
  }

  @Override
  public void delete(Long id) {
    vendorRepository.deleteById(id);
  }

}
