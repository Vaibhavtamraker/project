package in.matman.service.service;

import in.matman.service.AppConstants;
import in.matman.service.entity.Name;
import in.matman.service.entity.User;
import in.matman.service.entity.UserDto;
import in.matman.service.repository.AuthorityRepository;
import in.matman.service.repository.UserRepository;

import java.security.SecureRandom;
import java.util.List;

import in.matman.service.repository.VendorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

  private final UserRepository userRepository;
  private final AuthorityRepository authorityRepository;
  private final PasswordEncoder passwordEncoder;
  private final SecureRandom random = new SecureRandom();
  private final VendorRepository vendorRepository;

  @Autowired

  public UserServiceImpl(UserRepository userRepository, AuthorityRepository authorityRepository,
                         PasswordEncoder passwordEncoder, VendorRepository vendorRepository) {
    this.userRepository = userRepository;
    this.authorityRepository = authorityRepository;
    this.passwordEncoder = passwordEncoder;
    this.vendorRepository = vendorRepository;
  }

  @Override
  public User loadUserByUsername(String username) throws UsernameNotFoundException {
    return userRepository.findByUsername(username)
      .orElseThrow(() -> new UsernameNotFoundException(username + " not found!!"));
  }

  @Override
  public User createUser(UserDto userDto) {
    User user = new User();
    user.setAuthorities(authorityRepository.findAllById(userDto.getAuthorityIds()));  //refer
    user.setAccountNonLocked(true);
    user.setAccountNonExpired(true);
    user.setCredentialNonExpired(true);
    user.setEnabled(true);
    user.setMail(userDto.getMail());
    user.setMobile(userDto.getMobile());
    Name name = new Name();
    name.setFirstName(userDto.getFirstName());
    name.setLastName(userDto.getLastName());
    user.setName(name);
    user.setUsername(userDto.getUsername());
    // TODO: email it to user
    String plainTextPswd = generateRandomPassword(AppConstants.MAX_PASS_LEN);
    System.out.println(plainTextPswd);
    user.setPassword(passwordEncoder.encode(plainTextPswd));
    return userRepository.save(user);
  }

  @Override
  public User findUserById(Long id) {
    return userRepository.findById(id).get();
  }

  @Override
  public User updateUser(UserDto userdto, Long id) {

    User userdb = userRepository.findById(id).get();

    if (userdto.getUsername() != null) {
      userdb.setUsername(userdto.getUsername());
    }
    if (userdto.getMail() != null) {
      userdb.setMail(userdto.getMail());
    }

    if (userdto.getMobile() != null) {
      userdb.setMobile(userdto.getMobile());
    }

    if (userdto.getFirstName() != null) {
      userdb.getName().setFirstName(userdto.getFirstName());
    }
    if (userdto.getLastName() != null) {
      userdb.getName().setLastName(userdto.getLastName());
    }
    if (userdto.getAccountNonLocked() != null && !userdto.getAccountNonLocked()) {
      userdb.setAccountNonLocked(userdto.getAccountNonLocked());
    }
    if (userdto.getAccountNonExpired() != null && !userdto.getAccountNonExpired()) {
      userdb.setAccountNonExpired(userdto.getAccountNonExpired());
    }
    if (userdto.getCredentialNonExpired() != null && !userdto.getCredentialNonExpired()) {
      userdb.setAccountNonExpired(userdto.getAccountNonExpired());
    }
    if (userdto.getEnabled() != null && !userdto.getEnabled()) {
      userdb.setEnabled(userdto.getEnabled());
    }
    if (userdto.getAuthorityIds() != null && userdto.getAuthorityIds().size() > 0) {
      userdb.setAuthorities(authorityRepository.findAllById(userdto.getAuthorityIds()));
    }
    return userRepository.save(userdb);
  }

  public void deleteUser(Long id) {
    vendorRepository.findByContactPersons_Id(id).ifPresent(vendor -> {
      vendor.getContactPersons().removeIf(contactPerson -> contactPerson.getId().equals(id));
      vendorRepository.save(vendor);
    });
    userRepository.deleteById(id);
  }

  @Override
  public List<User> findAllUsers() {
    // TODO Auto-generated method stub
    return userRepository.findAll();
  }

  private String generateRandomPassword(int len) {

    StringBuilder sb = new StringBuilder();

    for (int i = 0; i < len; i++) {
      int randomIndex = random.nextInt(AppConstants.PASS_CHAR.length());
      sb.append(AppConstants.PASS_CHAR.charAt(randomIndex));
    }
    return sb.toString();
  }

  @Override
  public Optional<User> findByUsernameOrMobileOrMail(String username, String mobile, String mail) {
    return userRepository.findByUsernameOrMobileOrMail(username, mobile, mail);
  }
}
