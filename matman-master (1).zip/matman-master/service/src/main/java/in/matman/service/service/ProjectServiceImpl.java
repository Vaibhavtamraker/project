package in.matman.service.service;

import in.matman.service.entity.Project;
import in.matman.service.entity.ProjectDto;
import in.matman.service.repository.ProjectRepository;
import in.matman.service.repository.SiteRepository;
import in.matman.service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProjectServiceImpl implements ProjectService {

  private final ProjectRepository projectRepository;
  private final UserRepository userRepository;
  private final SiteRepository siteRepository;

  @Autowired
  public ProjectServiceImpl(ProjectRepository projectRepository, UserRepository userRepository, SiteRepository siteRepository) {
    this.projectRepository = projectRepository;
    this.userRepository = userRepository;
    this.siteRepository = siteRepository;
  }

  @Override
  public List<Project> findAll() {
    return projectRepository.findAll();
  }

  @Override
  public Project create(ProjectDto projectDto) {
    Project project = new Project();
    project.setTitle(projectDto.getTitle());
    project.setDescription(projectDto.getDescription());
    project.setSites(siteRepository.findAllById(projectDto.getSiteIds()));
    project.setAdmins(userRepository.findAllById(projectDto.getAdminIds()));
    project.setDesigners(userRepository.findAllById(projectDto.getDesignerIds()));
    project.setGateKeepers(userRepository.findAllById(projectDto.getGateKeeperIds()));
    project.setMaterialControllers(userRepository.findAllById(projectDto.getMaterialControllerIds()));
    return projectRepository.save(project);
  }

  @Override
  public Project update(Long id, ProjectDto projectDto) {
    Optional<Project> projectOptional = projectRepository.findById(id);
    if (projectOptional.isPresent()) {
      Project projectdb = projectOptional.get();
      if (projectDto.getTitle() != null)
        projectdb.setTitle(projectDto.getTitle());
      if (projectDto.getDescription() != null)
        projectdb.setDescription(projectDto.getDescription());
      if (projectDto.getSiteIds() != null && projectDto.getSiteIds().size() > 0)
        projectdb.setSites(siteRepository.findAllById(projectDto.getSiteIds()));
      if (projectDto.getAdminIds() != null && projectDto.getAdminIds().size() > 0)
        projectdb.setAdmins(userRepository.findAllById(projectDto.getAdminIds()));
      if (projectDto.getDesignerIds() != null && projectDto.getDesignerIds().size() > 0)
        projectdb.setDesigners(userRepository.findAllById(projectDto.getDesignerIds()));
      if (projectDto.getGateKeeperIds() != null && projectDto.getGateKeeperIds().size() > 0)
        projectdb.setGateKeepers(userRepository.findAllById(projectDto.getGateKeeperIds()));
      if (projectDto.getMaterialControllerIds() != null && projectDto.getMaterialControllerIds().size() > 0)
        projectdb.setMaterialControllers(userRepository.findAllById(projectDto.getMaterialControllerIds()));
      return projectRepository.save(projectdb);
    }
    return null;
  }

  @Override
  public void delete(Long id) {
    projectRepository.deleteById(id);
  }

}
