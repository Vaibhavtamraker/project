package in.matman.service.service;

import in.matman.service.entity.Item;
import in.matman.service.entity.ItemDto;
import in.matman.service.entity.Uom;
import in.matman.service.repository.ItemRepository;
import in.matman.service.repository.UomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemService {

  private final ItemRepository itemRepository;
  private final UomRepository uomRepository;

  @Autowired
  public ItemService(UomRepository uomRepository, ItemRepository itemRepository) {
    this.uomRepository = uomRepository;
    this.itemRepository = itemRepository;
  }

  public List<Item> findAll() {
    return itemRepository.findAll();
  }

  public Item findById(Long id) {
    return itemRepository.findById(id).get();
  }

  public Item create(ItemDto itemDto) {
    Item item = new Item();
    Optional<Uom> uomDb = uomRepository.findById(itemDto.getUomId());
    if (itemDto.getUomId() != null && uomDb.isPresent()) {
      item.setUom(uomDb.get());
    }
    item.setTitle(itemDto.getTitle());
    item.setDescription(itemDto.getDescription());
    return itemRepository.save(item);
  }

  public Item update(ItemDto itemDto, Long id) {
    Item itemdb = itemRepository.findById(id).get();
    if (itemDto.getTitle() != null) {
      itemdb.setTitle(itemDto.getTitle());
    }
    if (itemDto.getDescription() != null) {
      itemdb.setDescription(itemDto.getDescription());
    }
    Optional<Uom> uomDb = uomRepository.findById(itemDto.getUomId());
    if (itemDto.getUomId() != null && uomDb.isPresent()) {
      itemdb.setUom(uomDb.get());
    }
    return itemRepository.save(itemdb);
  }

  public void delete(Long id) {
    itemRepository.findById(id).ifPresent(item -> {
      item.setUom(null);
      itemRepository.save(item);
    });
    itemRepository.deleteById(id);
  }

}
