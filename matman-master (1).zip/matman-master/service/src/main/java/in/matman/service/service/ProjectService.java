package in.matman.service.service;

import in.matman.service.entity.Project;
import in.matman.service.entity.ProjectDto;

import java.util.List;

public interface ProjectService {

  List<Project> findAll();

  Project create(ProjectDto projectDto);

  Project update(Long id, ProjectDto projectDto);

  void delete(Long id);

}
