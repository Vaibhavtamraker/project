package in.matman.service.service;

import in.matman.service.entity.Site;
import in.matman.service.entity.Warehouse;

import java.util.List;

public interface WarehouseService {

  List<Warehouse> findAll();

  Warehouse create(Warehouse warehouse);

  Warehouse update(Long id, Warehouse warehouse);

  void delete(Long id);

}
