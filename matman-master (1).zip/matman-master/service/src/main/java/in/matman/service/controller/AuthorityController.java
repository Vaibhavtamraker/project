package in.matman.service.controller;

import in.matman.service.entity.Authority;
import in.matman.service.service.AuthorityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/authority")
public class AuthorityController {

    private final AuthorityService authorityService;

    @Autowired
    public AuthorityController(AuthorityService authorityService) {
        this.authorityService = authorityService;
    }

    @GetMapping
    public List<Authority> findAll() {
        return authorityService.findAll();
    }

    @GetMapping("/{id}")
    public Authority findById(@PathVariable Long id) {
        return authorityService.findById(id);
    }

}
