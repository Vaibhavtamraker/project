package in.matman.service.controller;

import in.matman.service.entity.ItemRequirement;
import in.matman.service.entity.ItemRequirementDto;
import in.matman.service.service.ItemRequirementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/item-requirement")
public class ItemRequirementController {

  private final ItemRequirementService itemRequirementService;

  @Autowired
  public ItemRequirementController(ItemRequirementService itemRequirementService) {
    this.itemRequirementService = itemRequirementService;
  }

  @GetMapping("/find-all")
  public List<ItemRequirement> all() {
    return itemRequirementService.findAll();
  }

  @PostMapping("/create")
  public List<ItemRequirement> create(@RequestBody List<ItemRequirementDto> itemRequirementDtos) {
    return itemRequirementService.create(itemRequirementDtos);
  }

  @PutMapping("/{id}/update")
  public ItemRequirement update(@PathVariable Long id, @RequestBody ItemRequirementDto itemRequirementDto) {
    return itemRequirementService.update(id, itemRequirementDto);
  }

  @DeleteMapping("/{id}/delete")
  public void delete(@PathVariable Long id) {
    itemRequirementService.delete(id);
  }

}
