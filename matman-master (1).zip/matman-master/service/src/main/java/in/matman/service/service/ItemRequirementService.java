package in.matman.service.service;

import in.matman.service.entity.ItemRequirement;
import in.matman.service.entity.ItemRequirementDto;

import java.util.List;

public interface ItemRequirementService {

  List<ItemRequirement> findAll();

  List<ItemRequirement> create(List<ItemRequirementDto> itemRequirementDtos);

  ItemRequirement update(Long id, ItemRequirementDto itemRequirementDto);

  void delete(Long id);

}
