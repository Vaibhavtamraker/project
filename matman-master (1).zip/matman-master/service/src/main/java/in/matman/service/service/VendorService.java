package in.matman.service.service;

import in.matman.service.entity.Vendor;
import in.matman.service.entity.VendorDto;

import java.util.List;

public interface VendorService {
    List<Vendor> findAll();

    Vendor findById(Long id);

    Vendor create(VendorDto vendorDto);

    Vendor update(VendorDto vendorDto, Long id);

    void delete(Long id);
}
