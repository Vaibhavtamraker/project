package in.matman.service.service;

import in.matman.service.entity.User;
import in.matman.service.entity.UserDto;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;
import java.util.Optional;

public interface UserService extends UserDetailsService {

    User createUser(UserDto userDto);

    Optional<User> findByUsernameOrMobileOrMail(String username, String mobile, String mail);

    User findUserById(Long id);

	  User updateUser(UserDto userdto, Long id);

	  void deleteUser(Long id);

	  List<User> findAllUsers();

}
