package in.matman.service.entity;

public enum WarehouseType {
  SHADED, ENCLOSED, OPEN
}
