package in.matman.service.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class Project {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;
  private String title;
  private String description;
  @OneToMany
  private List<User> designers;
  @OneToMany
  private List<User> gateKeepers;
  @OneToMany
  private List<User> materialControllers;
  @OneToMany
  private List<User> admins;
  @OneToMany
  private List<Site> sites;

  public Project() {
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public List<User> getGateKeepers() {
    return gateKeepers;
  }

  public void setGateKeepers(List<User> gateKeepers) {
    this.gateKeepers = gateKeepers;
  }

  public List<User> getMaterialControllers() {
    return materialControllers;
  }

  public void setMaterialControllers(List<User> materialControllers) {
    this.materialControllers = materialControllers;
  }

  public List<User> getAdmins() {
    return admins;
  }

  public void setAdmins(List<User> admins) {
    this.admins = admins;
  }

  public List<Site> getSites() {
    return sites;
  }

  public void setSites(List<Site> sites) {
    this.sites = sites;
  }

  public List<User> getDesigners() {
    return designers;
  }

  public void setDesigners(List<User> designers) {
    this.designers = designers;
  }

}
