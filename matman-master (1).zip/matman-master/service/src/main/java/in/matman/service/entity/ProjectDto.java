package in.matman.service.entity;

import java.util.List;

public class ProjectDto {

  private String title;
  private String description;
  private List<Long> designerIds;
  private List<Long> gateKeeperIds;
  private List<Long> materialControllerIds;
  private List<Long> adminIds;
  private List<Long> siteIds;

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public List<Long> getDesignerIds() {
    return designerIds;
  }

  public void setDesignerIds(List<Long> designerIds) {
    this.designerIds = designerIds;
  }

  public List<Long> getGateKeeperIds() {
    return gateKeeperIds;
  }

  public void setGateKeeperIds(List<Long> gateKeeperIds) {
    this.gateKeeperIds = gateKeeperIds;
  }

  public List<Long> getMaterialControllerIds() {
    return materialControllerIds;
  }

  public void setMaterialControllerIds(List<Long> materialControllerIds) {
    this.materialControllerIds = materialControllerIds;
  }

  public List<Long> getAdminIds() {
    return adminIds;
  }

  public void setAdminIds(List<Long> adminIds) {
    this.adminIds = adminIds;
  }

  public List<Long> getSiteIds() {
    return siteIds;
  }

  public void setSiteIds(List<Long> siteIds) {
    this.siteIds = siteIds;
  }
}
