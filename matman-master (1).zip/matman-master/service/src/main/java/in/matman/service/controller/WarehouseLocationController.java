package in.matman.service.controller;

import in.matman.service.entity.Warehouse;
import in.matman.service.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/warehouse")
public class WarehouseLocationController {

  private final WarehouseService warehouseService;

  @Autowired
  public WarehouseLocationController(WarehouseService warehouseService) {
    this.warehouseService = warehouseService;
  }

  @GetMapping("/find-all")
  public List<Warehouse> all() {
    return warehouseService.findAll();
  }

  @PostMapping("/create")
  public Warehouse create(@RequestBody Warehouse warehouse) {
    return warehouseService.create(warehouse);
  }

  @PutMapping("/{id}/update")
  public Warehouse update(@PathVariable Long id, @RequestBody Warehouse warehouse) {
    return warehouseService.update(id, warehouse);
  }

  @DeleteMapping("/{id}/delete")
  public void delete(@PathVariable Long id) {
    warehouseService.delete(id);
  }

}
