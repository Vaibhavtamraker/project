package in.matman.service.service;

import in.matman.service.entity.Site;
import in.matman.service.entity.SiteDto;

import java.util.List;

public interface SiteService {
  List<Site> findAll();

  Site create(SiteDto siteDto);

  Site update(Long id, SiteDto siteDto);

  void delete(Long id);
}
