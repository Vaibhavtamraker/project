package in.matman.service.service;

import in.matman.service.entity.Site;
import in.matman.service.entity.SiteDto;
import in.matman.service.repository.SiteRepository;
import in.matman.service.repository.UserRepository;
import in.matman.service.repository.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SiteServiceImpl implements SiteService {

  private final SiteRepository siteRepository;
  private final UserRepository userRepository;
  private final WarehouseRepository warehouseRepository;

  @Autowired
  public SiteServiceImpl(SiteRepository siteRepository, UserRepository userRepository, WarehouseRepository warehouseRepository) {
    this.siteRepository = siteRepository;
    this.userRepository = userRepository;
    this.warehouseRepository = warehouseRepository;
  }

  @Override
  public List<Site> findAll() {
    return siteRepository.findAll();
  }

  @Override
  public Site create(SiteDto siteDto) {
    Site site = new Site();
    site.setName(siteDto.getName());
    site.setAddress(siteDto.getAddress());
    site.setCity(siteDto.getCity());
    site.setState(siteDto.getState());
    site.setForemans(userRepository.findAllById(siteDto.getForemanIds()));
    site.setWarehouseLocations(warehouseRepository.findAllById(siteDto.getWarehouseLocationIds()));
    return siteRepository.save(site);
  }

  @Override
  public Site update(Long id, SiteDto siteDto) {
    Optional<Site> siteOptional = siteRepository.findById(id);
    if (siteOptional.isPresent()) {
      Site sitedb = siteOptional.get();
      if (siteDto.getAddress() != null)
        sitedb.setAddress(siteDto.getAddress());
      if (siteDto.getCity() != null)
        sitedb.setCity(siteDto.getCity());
      if (siteDto.getName() != null)
        sitedb.setName(siteDto.getName());
      if (siteDto.getState() != null)
        sitedb.setState(siteDto.getState());
      if (siteDto.getForemanIds() != null && siteDto.getForemanIds().size() > 0)
        sitedb.setForemans(userRepository.findAllById(siteDto.getForemanIds()));
      if (siteDto.getWarehouseLocationIds() != null && siteDto.getWarehouseLocationIds().size() > 0)
        sitedb.setWarehouseLocations(warehouseRepository.findAllById(siteDto.getWarehouseLocationIds()));
      return siteRepository.save(sitedb);
    }
    return null;
  }

  @Override
  public void delete(Long id) {
    siteRepository.deleteById(id);
  }
}
