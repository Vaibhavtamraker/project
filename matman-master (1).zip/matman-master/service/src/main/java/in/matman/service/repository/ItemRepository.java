package in.matman.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.matman.service.entity.Item;
import in.matman.service.entity.ItemDto;

@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {
}
