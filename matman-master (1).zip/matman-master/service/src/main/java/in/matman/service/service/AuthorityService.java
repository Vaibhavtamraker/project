package in.matman.service.service;

import in.matman.service.entity.Authority;

import java.util.List;

public interface AuthorityService {
    List<Authority> findAll();

    Authority findById(Long id);
}
