package in.matman.service.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.matman.service.entity.Uom;

import in.matman.service.service.UomService;

@RestController
@RequestMapping("/api/v1")
public class UomController {

  private final UomService uomService;

  @Autowired
  public UomController(UomService uomService) {
    this.uomService = uomService;
  }

  //	for find all
  @GetMapping("/uom/find-all")
  public List<Uom> findAll() {
    return uomService.findAll();
  }

  //	for findbyid
  @GetMapping("/uom/{id}")
  public Uom one(@PathVariable Long id) {
    return uomService.findById(id);
  }

  //for creating new uom
  @PostMapping("/uom/create")
  public Uom create(@RequestBody Uom uom) {
    return uomService.create(uom);
  }

  //	  for updating
  @PutMapping("/uom/{id}/update")
  public Uom update(@RequestBody Uom uom, @PathVariable Long id) {
    return uomService.update(uom, id);
  }

  @DeleteMapping("/uom/{id}/delete")
  public void delete(@PathVariable Long id) {
    uomService.delete(id);
  }

}
