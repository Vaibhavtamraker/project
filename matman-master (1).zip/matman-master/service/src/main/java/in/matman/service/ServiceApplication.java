package in.matman.service;

import in.matman.service.entity.Authority;
import in.matman.service.entity.Uom;
import in.matman.service.entity.User;
import in.matman.service.entity.UserDto;
import in.matman.service.repository.UserRepository;
import in.matman.service.service.UomService;
import in.matman.service.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import in.matman.service.repository.AuthorityRepository;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@SpringBootApplication
public class ServiceApplication implements CommandLineRunner {

  private final UserService userService;
  private final UserRepository userRepository;
  private final AuthorityRepository authorityRepository;
  private final UomService uomService;
  private final PasswordEncoder passwordEncoder;
  Logger logger = LoggerFactory.getLogger(ServiceApplication.class);

  @Autowired
  public ServiceApplication(UserService userService, UserRepository userRepository, AuthorityRepository authorityRepository, UomService uomService, PasswordEncoder passwordEncoder) {
    this.userService = userService;
    this.userRepository = userRepository;
    this.authorityRepository = authorityRepository;
    this.uomService = uomService;
    this.passwordEncoder = passwordEncoder;
  }

  public static void main(String[] args) {
    SpringApplication.run(ServiceApplication.class, args);
  }

  @Override
  public void run(String... args) throws Exception {
    Uom uom = new Uom();
    uom.setName("Centimeter");
    uom.setSymbol("cm");
    uomService.create(uom);
    List<Authority> dbAuthorities;
    if (authorityRepository.count() == 0) {
      List<Authority> authorities = new ArrayList<>();
      Authority authority = new Authority();
      authority.setAuthority("VENDOR");
      authority.setDescription("This role will allow users to feed rates of their catalogue materials into the system, manage orders and view their order deadlines.");
      authorities.add(authority);
      authority = new Authority();
      authority.setAuthority("ADMIN");
      authority.setDescription("This role will allow all operations to be performed. Users with this role can manage all data of the system.");
      authorities.add(authority);
      authority = new Authority();
      authority.setAuthority("MATERIAL_MANAGER");
      authority.setDescription("This role will allow material controller of the company / project to manage procurement orders, prepare purchase orders, approve quotations and manage materials in warehouse and recording of outgoing materials from warehouse to site.");
      authorities.add(authority);
      authority = new Authority();
      authority.setAuthority("GATE_KEEPER");
      authority.setDescription("This role will allow security in charge of warehouse to record material delivery, acknowledging of gate pass for outgoing materials to the site.");
      authorities.add(authority);
      authority = new Authority();
      authority.setAuthority("FOREMAN");
      authority.setDescription("This role will enable onsite in charge to record consumption / non - consumption of allocated materials at the site. This module will also be used to return unused materials back to the warehouse.");
      authorities.add(authority);
      authority = new Authority();
      authority.setAuthority("PLANNER");
      authority.setDescription("This role will allow planners of project to entire their item requirements in the system.");
      authorities.add(authority);
      dbAuthorities = authorityRepository.saveAll(authorities);
    } else {
      dbAuthorities = authorityRepository.findAll();
    }
    UserDto userDto = new UserDto();
    userDto.setAuthorityIds(dbAuthorities.stream().map(Authority::getId).collect(Collectors.toSet()));
    userDto.setFirstName("Jaiesh");
    userDto.setLastName("Bhagat");
    userDto.setMail("jaiesh.bhagat@gmail.com");
    userDto.setMobile("9967445869");
    userDto.setUsername("jaiesh.bhagat");
    User user = userService.createUser(userDto);
    user.setPassword(passwordEncoder.encode("password"));
    userRepository.save(user);
    logger.info("User created successfully", user);
  }

}
