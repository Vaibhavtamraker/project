import {Injectable} from "@angular/core";
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from "@angular/common/http";
import {finalize, tap} from "rxjs/operators";
import {Router} from "@angular/router";
import {SpinnerService} from "./service/spinner.service";
import {Observable} from "rxjs";

@Injectable({
    providedIn: "root"
})
export class XhrInterceptor implements HttpInterceptor {

    constructor(private router: Router, public spinnerService: SpinnerService) {
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.spinnerService.show();
        const xhr = req.clone({
            headers: req.headers.set('X-Requested-With', 'XMLHttpRequest'),
            withCredentials: true
        });
        return next.handle(xhr).pipe(
            tap(
                () => {
                },
                (err: any) => {
                    if (err instanceof HttpErrorResponse) {
                        if (err.status !== 401 && err.status !== 403) {
                            return;
                        }
                        this.router.navigate(['/login']);
                    }
                }
            ),
            finalize(
                () => this.spinnerService.hide()
            )
        );
    }

}
