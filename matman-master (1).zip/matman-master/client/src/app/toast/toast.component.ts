import {Component, OnInit, TemplateRef} from '@angular/core';
import {ToastService} from "../service/toast.service";
import {Toast} from "../model";

@Component({
    selector: 'app-toast',
    template: `
        <ngb-toast *ngFor="let toast of toasts" [class]="toast.classname" [autohide]="true" [delay]="toast.delay || 5000"
                   (hidden)="remove(toast)">
            <ng-template [ngIf]="isTemplate(toast)" [ngIfElse]="text">
                <ng-template [ngTemplateOutlet]="tpl(toast)"></ng-template>
            </ng-template>
            <ng-template #text>{{ toast.textOrTpl }}</ng-template>
        </ngb-toast>
    `,
    styles: [],
    host: {'[class.ngb-toasts]': 'true'}
})
export class ToastComponent implements OnInit {

    constructor(private toastService: ToastService) {
    }

    get toasts() {
        return this.toastService.toasts;
    }

    isTemplate(toast: Toast) {
        return toast.textOrTpl instanceof TemplateRef;
    }

    tpl(toast: Toast): TemplateRef<any> {
        return <TemplateRef<any>>toast.textOrTpl;
    }

    remove(toast: Toast) {
        this.toastService.remove(toast);
    }

    ngOnInit(): void {
    }

}
