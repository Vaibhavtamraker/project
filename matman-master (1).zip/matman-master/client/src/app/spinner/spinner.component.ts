import {Component, OnInit} from '@angular/core';
import {SpinnerService} from "../service/spinner.service";

@Component({
    selector: 'app-spinner',
    template: `
        <div class="spinner spinner-border" role="status" *ngIf="spinnerService.isLoading | async"></div>`,
    styles: ['.spinner { position: absolute;left: 50%;top: 50%;margin:0px auto;}']
})
export class SpinnerComponent implements OnInit {

    constructor(public spinnerService: SpinnerService) {
    }

    ngOnInit(): void {
    }

}
