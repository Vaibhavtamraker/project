import {Injectable} from '@angular/core';
import {Observable} from "rxjs";
import {User, UserDto} from "../model";
import {HttpClient} from "@angular/common/http";
import {environment} from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) {
  }

  fetchAll(): Observable<User[]> {
    return this.http.get<User[]>(environment.baseUrl + '/user/find-all');
  }

  create(userDto: UserDto): Observable<User> {
    return this.http.post<User>(environment.baseUrl + '/user/create', userDto);
  }

  update(id: number, userDto: UserDto): Observable<User> {
    return this.http.put<User>(environment.baseUrl + '/user/' + id + '/update', userDto);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(environment.baseUrl + '/user/' + id + '/delete');
  }

}
