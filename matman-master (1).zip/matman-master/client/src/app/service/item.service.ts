import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Item, ItemDto} from "../model";
import {environment} from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  constructor(private http: HttpClient) {
  }

  fetchAll(): Observable<Item[]> {
    return this.http.get<Item[]>(environment.baseUrl + '/item/find-all');
  }

  create(itemDto: ItemDto): Observable<Item> {
    return this.http.post<Item>(environment.baseUrl + '/item/create', itemDto);
  }

  update(id: number, itemDto: ItemDto): Observable<Item> {
    return this.http.put<Item>(environment.baseUrl + '/item/' + id + '/update', itemDto);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(environment.baseUrl + '/item/' + id + '/delete');
  }

}
