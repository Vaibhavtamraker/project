import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {environment} from 'client/src/environments/environment';
import {Observable} from 'rxjs';
import {ItemRequirement, ItemRequirementDto} from '../model';

@Injectable({
  providedIn: 'root'
})
export class ItemRequirementService {

  constructor(private http: HttpClient) {
  }

  fetchAll(): Observable<ItemRequirement[]> {
    return this.http.get<ItemRequirement[]>(environment.baseUrl + '/item-requirement/find-all');
  }

  create(itemRequirementDto: ItemRequirementDto[]): Observable<ItemRequirement[]> {
    return this.http.post<ItemRequirement[]>(environment.baseUrl + '/item-requirement/create', itemRequirementDto);
  }

  update(id: number, itemRequirementDto: ItemRequirementDto): Observable<ItemRequirement> {
    return this.http.put<ItemRequirement>(environment.baseUrl + '/item-requirement/' + id + '/update', itemRequirementDto);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(environment.baseUrl + '/item-requirement/' + id + '/delete');
  }

}
