import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {Vendor, VendorDto} from "../model";
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VendorService {

  constructor(private http: HttpClient) {
  }

  fetchAll(): Observable<Vendor[]> {
    return this.http.get<Vendor[]>(environment.baseUrl + '/vendor/find-all')
  }

  create(vendorDto: VendorDto): Observable<Vendor> {
    return this.http.post<Vendor>(environment.baseUrl + '/vendor/create', vendorDto);
  }

  update(id: number, vendorDto: VendorDto): Observable<Vendor> {
    return this.http.put<Vendor>(environment.baseUrl + '/vendor/' + id, vendorDto);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(environment.baseUrl + '/vendor/' + id + '/delete');
  }

}
