import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Authority } from '../model';

@Injectable({
  providedIn: 'root'
})
export class AuthorityService {

  constructor(private http: HttpClient) { }

    fetchAll():Observable<Authority[]>{
        return this.http.get<Authority[]>(environment.baseUrl+'/authority');
    }

}
