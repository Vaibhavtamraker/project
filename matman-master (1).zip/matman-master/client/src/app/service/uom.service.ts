import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Uom, User, UserDto} from "../model";
import {DecimalPipe} from "@angular/common";
import {environment} from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class UomService {

  constructor(private http: HttpClient) {
  }

  fetchAll(): Observable<Uom[]> {
    return this.http.get<Uom[]>(environment.baseUrl + '/uom/find-all');
  }

  create(uom: Uom): Observable<Uom> {
    return this.http.post<Uom>(environment.baseUrl + '/uom/create', uom);
  }

  update(id: number, uom: Uom): Observable<Uom> {
    return this.http.put<Uom>(environment.baseUrl + '/uom/' + id + '/update', uom);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(environment.baseUrl + '/uom/' + id + '/delete');
  }
}
