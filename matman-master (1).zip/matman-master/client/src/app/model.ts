import {TemplateRef} from "@angular/core";

export interface Credential {
  username: string;
  password: string;
}

export interface User {
  id: number;
  username: string;
  mail: string;
  mobile: string;
  name: Name;
  authorities: Authority[];
  accountNonLocked: boolean;
  accountNonExpired: boolean;
  credentialNonExpired: boolean;
  enabled: boolean;
  credentialsNonExpired: boolean;
  lastSignedInTime: string;
}

export interface Vendor {
  id: number;
  name: string;
  address: string;
  pinCode: number;
  city: string;
  state: string;
  country: string;
  contactPersons: User[];
}

export interface VendorDto {
  name: string;
  address: string;
  pinCode: number;
  city: string;
  state: string;
  country: string;
  contactPersons: UserDto[];
}

export interface UserDto {
  username: string;
  mail: string;
  mobile: string;
  firstName: string;
  lastName: string;
  authorityIds: number[];
}

export interface ItemRequirement {
  id: number;
  item: Item;
  quantity: number;
  processed: boolean;
  createdOn: Date;
  modifiedOn: Date;
  createdBy: User;
}

export interface ItemRequirementDto {
  itemId: number;
  quantity: number;
}


export interface Name {
  firstName: string;
  lastName: string;
}

export interface Authority {
  id: number;
  authority: string;
  description: string;
}

export interface Toast {
  textOrTpl: string | TemplateRef<any>;
  classname: string;
  delay: number;
}

export interface Uom {
  id: number;
  name: string;
  symbol: string;
}

export class Table<T> {

  private _rows: T[] = [];
  private _state: TableState<T> = {
    page: 1,
    pageSize: 5,
    sortColumn: '',
    sortDirection: '',
    searchTerm: '',
    collectionSize: 0
  };

  get rows(): T[] {
    return this._rows;
  }

  set rows(value: T[]) {
    this._rows = value;
  }

  get page() {
    return this._state.page;
  }

  set page(page: number) {
    this._state.page = page;
  }

  get pageSize() {
    return this._state.pageSize;
  }

  set pageSize(pageSize: number) {
    this._state.pageSize = pageSize;
  }

  get sortColumn() {
    return this._state.sortColumn;
  }

  set sortColumn(sortColumn: SortColumn<T>) {
    this._state.sortColumn = sortColumn;
  }

  get sortDirection() {
    return this._state.sortDirection;
  }

  set sortDirection(sortDirection: SortDirection) {
    this._state.sortDirection = sortDirection;
  }

  get searchTerm() {
    return this._state.searchTerm;
  }

  set searchTerm(searchTerm: string) {
    this._state.searchTerm = searchTerm;
  }

  get collectionSize() {
    return this._state.collectionSize;
  }

  set collectionSize(collectionSize: number) {
    this._state.collectionSize = collectionSize;
  }

}

export interface TableState<T> {
  page: number;
  pageSize: number;
  searchTerm: string;
  sortColumn: SortColumn<T>;
  sortDirection: SortDirection;
  collectionSize: number;
}

export interface SortEvent<T> {
  column: SortColumn<T>;
  direction: SortDirection;
}

export type SortColumn<T> = keyof T | '';
export type SortDirection = 'asc' | 'desc' | '';

export interface Item {
  id: number;
  title: string;
  description: string;
  uom: Uom;
}

export interface ItemDto {
  title: string;
  description: string;
  uomId: number;
}
