import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginComponent} from './login/login.component';
import {DashboardComponent} from './views/dashboard/dashboard.component';
import {DashboardLayoutComponent} from "./dashboard-layout/dashboard-layout.component";
import {AuthGuard} from "./auth-guard";
import {UomComponent} from "./views/uom/uom.component";
import {AuthorityComponent} from './views/authority/authority.component';
import {UsersComponent} from "./views/users/users.component";
import {VendorsComponent} from './views/vendors/vendors.component';
import {ItemsComponent} from "./views/items/items.component";
import { ItemRequirementsComponent } from './views/item-requirements/item-requirements.component';


const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '',
    component: DashboardLayoutComponent,
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'uom',
        component: UomComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'authority',
        component: AuthorityComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'users',
        component: UsersComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'vendors',
        component: VendorsComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'items',
        component: ItemsComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'item-requirements',
        component: ItemRequirementsComponent,
        canActivate: [AuthGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
