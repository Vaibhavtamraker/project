import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {Router} from "@angular/router";
import {environment} from "../environments/environment";
import {Credential, User} from "./model";
import {finalize} from "rxjs/operators";
import {ToastService} from "./service/toast.service";

const USER_PROFILE = 'user-profile';

@Injectable({
    providedIn: 'root'
})
export class AppService {

    authenticated: boolean = false;
    redirectUrl: string | null = null;
  User$: any;
  total$: any;

    constructor(private http: HttpClient, private router: Router, private toastService: ToastService) {
        this.authenticate(undefined, undefined);
    }

    authenticate(credentials?: Credential, successCallback?: any, errorCallback?: any) {
        const headers = new HttpHeaders(credentials ? {
            authorization: 'Basic ' + btoa(credentials.username + ':' + credentials.password)
        } : {});
        this.http.get<User>(environment.baseUrl + '/user', {headers: headers}).subscribe(response => {
            if (response != null && Object.keys(response).length) {
                this.authenticated = true;
                sessionStorage.setItem(USER_PROFILE, btoa(JSON.stringify(response)));
                if (this.redirectUrl) {
                    this.router.navigate([this.redirectUrl]);
                    this.redirectUrl = null;
                } else
                    this.router.navigate(['/']);
            } else {
                this.authenticated = false;
            }
            return successCallback && successCallback(response);
        }, (responseError: HttpErrorResponse) => {
            return errorCallback && errorCallback(responseError);
        });
    }

    logout(successCallback?: any, errorCallback?: any) {
        this.http.post(environment.baseUrl + '/logout', null).pipe(finalize(() => {
            this.authenticated = false;
            sessionStorage.removeItem(USER_PROFILE);
            this.router.navigateByUrl('/login');
        })).subscribe(response => {
                return successCallback && successCallback(response);
            }, (errorResponse: HttpErrorResponse) => {
                return errorCallback && errorCallback(errorResponse);
            });
    }

    get authenticatedUser(): User {
        return <User>JSON.parse(atob(<string>sessionStorage.getItem(USER_PROFILE)));
    }

}
