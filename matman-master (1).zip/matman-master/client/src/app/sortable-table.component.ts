import {Directive, PipeTransform, QueryList, ViewChildren} from "@angular/core";
import {SortableDirective} from "./sortable.directive";
import {SortEvent, Table} from "./model";
import {FormControl} from "@angular/forms";
import {map, startWith} from "rxjs/operators";
import {DecimalPipe} from "@angular/common";

@Directive()
export abstract class SortableTableComponent<T> {

  @ViewChildren(SortableDirective)
  headers: QueryList<SortableDirective<T>> = new QueryList<SortableDirective<T>>();
  data: Array<T> = [];
  public filter = new FormControl('');
  table: Table<T> = new Table<T>();
  selected: Array<T> = [];

  /**
   * Whether the number of selected elements matches the total number of rows.
   */
  isAllSelected():boolean {
    const numSelected = this.selected.length;
    const numRows = this.data.length;
    return numSelected === numRows;
  }

  /**
   * Selects all rows if they are not all selected; otherwise clear selection.
   */
  masterToggle() {
    this.isAllSelected() ?
      this.selected = [] :
      this.data.forEach(row => this.selected.push(row));
  }

  protected constructor(pipe: DecimalPipe) {
    this.filter.valueChanges.pipe(
      startWith(''),
      map(text => this.search(text, pipe))
    ).subscribe(uoms => {
      this.table.rows = uoms.slice((this.table.page - 1) * this.table.pageSize, (this.table.page - 1) * this.table.pageSize + this.table.pageSize);
      this.table.collectionSize = uoms.length;
    });
  }

  onSort({column, direction}: SortEvent<T>): void {

    this.table.sortDirection = direction;
    this.table.sortColumn = column;

    this.headers.forEach(header => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });

    if (direction === '' || column === '') {
      this.onPageChange();
    } else {
      this.data = [...this.data].sort((a: T, b: T) => {
        const res = Object.values(a[column]).join(' ') < Object.values(b[column]).join(' ') ? -1 : Object.values(a[column]).join(' ') > Object.values(b[column]).join(' ') ? 1 : 0;
        return direction === 'asc' ? res : -res;
      });
      this.onPageChange();
    }
  }

  /**
   * Abstract function to implement search / filter table data based on 'searchTerm'.
   * @abstract
   * @return array of data matching 'searchTerm'
   * @param searchTerm
   * @param pipe
   */
  abstract search(searchTerm: string, pipe: PipeTransform): T[];

  onPageChange() {
    this.table.rows = this.data.slice((this.table.page - 1) * this.table.pageSize, (this.table.page - 1) * this.table.pageSize + this.table.pageSize);
  }

  toggleSelection(data: T) {
    this.selected.includes(data) ? this.selected.forEach((value, index) => {
      if (value == data) this.selected.splice(index, 1);
    }) : this.selected.push(data);
  }

}
