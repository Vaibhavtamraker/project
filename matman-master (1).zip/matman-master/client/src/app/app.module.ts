import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {LoginComponent} from './login/login.component';
import {SidebarComponent} from './sidebar/sidebar.component';
import {DashboardComponent} from './views/dashboard/dashboard.component';
import {DashboardLayoutComponent} from './dashboard-layout/dashboard-layout.component';
import {NavbarComponent} from './navbar/navbar.component';
import {AppService} from './app.service';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {XhrInterceptor} from "./xhr.interceptor";
import {ToastComponent} from './toast/toast.component';
import {UomComponent} from './views/uom/uom.component';
import {SpinnerComponent} from './spinner/spinner.component';
import {SpinnerService} from "./service/spinner.service";
import {DecimalPipe} from "@angular/common";
import {SortableDirective} from './sortable.directive';
import {AuthorityComponent} from './views/authority/authority.component';
import {ViewComponent} from './views/authority/view/view.component';
import {UsersComponent} from "./views/users/users.component";
import { UserFormComponent } from './views/users/user-form/user-form.component';
import { UomFormComponent } from './views/uom/uom-form/uom-form.component';
import { VendorsComponent } from './views/vendors/vendors.component';
import { VendorFormComponent } from './views/vendors/vendor-form/vendor-form.component';
import { ItemsComponent } from './views/items/items.component';
import { ItemFormComponent } from './views/items/item-form/item-form.component';
import { ItemRequirementsComponent } from './views/item-requirements/item-requirements.component';
import { ItemRequirementFormComponent } from './views/item-requirements/item-requirement-form/item-requirement-form.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SidebarComponent,
    DashboardComponent,
    DashboardLayoutComponent,
    NavbarComponent,
    ToastComponent,
    UomComponent,
    SpinnerComponent,
    SortableDirective,
    AuthorityComponent,
    ViewComponent,
    UsersComponent,
    UserFormComponent,
    UomFormComponent,
    ItemsComponent,
    ItemFormComponent,
    UomFormComponent,
    VendorsComponent,
    VendorFormComponent,
    ItemRequirementsComponent,
    ItemRequirementFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [AppService, SpinnerService, DecimalPipe, {
    provide: HTTP_INTERCEPTORS,
    useClass: XhrInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule {
}
