import {Component, OnInit} from '@angular/core';
import {AppService} from "../app.service";
import {ToastService} from "../service/toast.service";
import {HttpErrorResponse} from "@angular/common/http";

@Component({
    selector: 'app-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.css']

})
export class NavbarComponent implements OnInit {

    constructor(private appService: AppService, private toastService: ToastService) {
    }

    ngOnInit(): void {
    }

    logout() {
        this.appService.logout(() => {
                this.toastService.show('Logout Successful', {classname: 'bg-success text-light', delay: 10000});
            },
            (errorResponse: HttpErrorResponse) => {
                this.toastService.show('Logout Unsuccessful ' + errorResponse.message, {classname: 'bg-danger', delay: 10000});
            });
    }

    get authenticatedUser() {
        return this.appService.authenticatedUser;
    }

}
