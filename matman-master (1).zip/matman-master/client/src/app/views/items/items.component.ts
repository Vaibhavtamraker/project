import {Component, OnInit, PipeTransform} from '@angular/core';
import {SortableTableComponent} from "../../sortable-table.component";
import {Authority, Item, Uom} from "../../model";
import {ItemService} from "../../service/item.service";
import {DecimalPipe} from "@angular/common";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {ToastService} from "../../service/toast.service";
import {ViewComponent} from "../authority/view/view.component";
import {ItemFormComponent} from "../items/item-form/item-form.component";
import {environment} from "../../../environments/environment";
import {UomFormComponent} from "../uom/uom-form/uom-form.component";

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent extends SortableTableComponent<Item> implements OnInit {

  constructor(private itemService: ItemService, pipe: DecimalPipe, private modalService: NgbModal, private toastService: ToastService) {
    super(pipe);
    this.itemService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
    });
  }

  search(searchTerm: string, pipe: PipeTransform): Item[] {
    return searchTerm === '' ? this.data : this.data.filter(item => {
      searchTerm = searchTerm.toLowerCase();
      return (item.title + item.description + item.uom.name + item.uom.symbol).toLowerCase().includes(searchTerm)
        || pipe.transform(item.id).includes(searchTerm);
    }).slice((this.table.page - 1) * this.table.pageSize, (this.table.page - 1) * this.table.pageSize + this.table.pageSize);
  }

  ngOnInit(): void {
  }

  viewItem(item: Item): void {
    const modal = this.modalService.open(ItemFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.item = item;
    modal.componentInstance.readonly = true;
  }

  openForm(item?: Item) {
    const modal = this.modalService.open(ItemFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.item = item;
    modal.closed.subscribe(formItem => {
      let index = this.data.findIndex(dataItem => dataItem.id == formItem.id);
      if (index === -1) {
        this.data.push(formItem);
        this.table.collectionSize = this.data.length;
        this.selected = [];
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      } else {
        this.selected = [];
        this.data[index] = formItem;
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      }
    });
  }

  delete(): void {
    this.selected.forEach((item) => this.itemService.delete(item.id).subscribe(() => {
        this.data.splice(this.data.indexOf(item), 1);
        this.selected.splice(this.selected.indexOf(item), 1);
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      })
    );
  }

  refreshData(): void {
    this.itemService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
      this.toastService.show('Data refreshed', {classname: 'bg-success text-light', delay: 10000});
    }, (error) => this.toastService.show('Could not update items. Please try again after sometime.', {
      classname: 'bg-danger',
      delay: environment.toastDisplayTime
    }));
  }

  viewUom(uom: Uom): void {
    const modal = this.modalService.open(UomFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.uom = uom;
    modal.componentInstance.readonly = true;
  }

}
