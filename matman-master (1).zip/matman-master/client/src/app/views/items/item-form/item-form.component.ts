import {Component, Input, OnInit} from '@angular/core';
import {Authority, Item, Uom} from "../../../model";
import {FormBuilder, FormGroup} from "@angular/forms";
import {NgbActiveModal, NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {AuthorityService} from "../../../service/authority.service";
import {ItemService} from "../../../service/item.service";
import {ToastService} from "../../../service/toast.service";
import {ViewComponent} from "../../authority/view/view.component";
import {UomService} from "../../../service/uom.service";
import {UomFormComponent} from "../../uom/uom-form/uom-form.component";

@Component({
  selector: 'app-item-form',
  templateUrl: './item-form.component.html',
  styleUrls: ['./item-form.component.css']
})
export class ItemFormComponent implements OnInit {

  @Input() item: Item | undefined;
  @Input() readonly: boolean = false;
  uoms: Uom[] = [];
  itemForm: FormGroup;

  constructor(public activeModal: NgbActiveModal, private uomService: UomService, private itemService: ItemService, private fb: FormBuilder, private toastService: ToastService, private modalService: NgbModal) {
    this.uomService.fetchAll().subscribe(uoms => {
      this.uoms = uoms;
    });
    this.itemForm = this.fb.group({
      title: [''],
      description: [''],
      uomId: ['']
    });
  }

  ngOnInit(): void {
    if (this.item) {
      this.itemForm.get('title')?.setValue(this.item.title);
      this.itemForm.get('description')?.setValue(this.item.description);
      this.itemForm.get('uomId')?.setValue(this.item.uom.id);
    }
  }

  onSubmit() {
    if (this.item)
      this.itemService.update(this.item.id, this.itemForm.value).subscribe(response => {
        this.activeModal.close(response);
        this.toastService.show('Item updated successfully.', {classname: 'bg-success text-light', delay: 10000});
      }, error => {
        this.toastService.show('Could not update item. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: 10000
        });
        this.activeModal.dismiss();
      });
    else
      this.itemService.create(this.itemForm.value).subscribe(response => {
        this.activeModal.close(response);
        this.toastService.show('Item created successfully.', {classname: 'bg-success text-light', delay: 10000});
      }, error => {
        this.toastService.show('Could not create new item. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: 10000
        });
        this.activeModal.dismiss();
      });
  }

  viewUom(uom: Uom): void {
    const modal = this.modalService.open(UomFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.uom = uom;
    modal.componentInstance.readonly = true;
  }

  openUomForm() {
    const modalUom = this.modalService.open(UomFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modalUom.closed.subscribe((uom: Uom) => {
      this.uoms.push(uom);
      this.itemForm.get('uomId')?.setValue(uom.id);
    });
  }

}
