import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {Item, ItemRequirement, ItemRequirementDto, User} from 'client/src/app/model';
import {ItemRequirementService} from 'client/src/app/service/item-requirement.service';
import {ToastService} from 'client/src/app/service/toast.service';
import {environment} from 'client/src/environments/environment';
import {ItemService} from "../../../service/item.service";
import {ItemFormComponent} from "../../items/item-form/item-form.component";
import {UserFormComponent} from "../../users/user-form/user-form.component";

@Component({
  selector: 'app-item-requirement-form',
  templateUrl: './item-requirement-form.component.html',
  styleUrls: ['./item-requirement-form.component.css']
})
export class ItemRequirementFormComponent implements OnInit {
  @Input() itemRequirement: ItemRequirement | undefined;
  @Input() readonly: boolean = false;
  items: Item[] = [];
  itemRequirementForm: FormGroup;
  itemRequirementDtos: ItemRequirementDto[] = [];

  constructor(public activeModal: NgbActiveModal, private itemRequirementService: ItemRequirementService, private itemService: ItemService, private fb: FormBuilder, private toastService: ToastService, private modalService: NgbModal) {
    this.itemService.fetchAll().subscribe(items => {
      this.items = items;
    });
    this.itemRequirementForm = this.fb.group({
      itemId: ['', Validators.required],
      quantity: ['', [Validators.required, Validators.max(99999), Validators.min(1)]]
    });
  }

  ngOnInit(): void {
    if (this.itemRequirement) {
      this.itemRequirementForm.get('itemId')?.setValue(this.itemRequirement.item.id);
      this.itemRequirementForm.get('quantity')?.setValue(this.itemRequirement.quantity);
    }
  }

  onSubmit() {
    if (this.itemRequirement)
      this.itemRequirementService.update(this.itemRequirement.id, this.itemRequirementForm.value).subscribe(response => {
        this.activeModal.close([response]);
        this.toastService.show('Item Requirement updated successfully.', {
          classname: 'bg-success text-light',
          delay: environment.toastDisplayTime
        });
      }, error => {
        this.toastService.show('Could not update Item Requirements. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: environment.toastDisplayTime
        });
        this.activeModal.dismiss();
      });
    else
      this.itemRequirementService.create(this.itemRequirementDtos).subscribe(response => {
        this.activeModal.close(response);
        this.toastService.show('Item Requirement created successfully.', {
          classname: 'bg-success text-light',
          delay: environment.toastDisplayTime
        });
      }, error => {
        this.toastService.show('Could not create new Item Requirements. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: environment.toastDisplayTime
        });
        this.activeModal.dismiss();
      });
  }

  viewItem(item: Item): void {
    const modal = this.modalService.open(ItemFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.item = item;
    modal.componentInstance.readonly = true;
  }

  openItemForm() {
    const modal = this.modalService.open(ItemFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.closed.subscribe((item: Item) => {
      this.items.push(item);
      this.itemRequirementForm.get('itemId')?.value.push(item.id);
    });
  }

  item(itemId: number): Item | undefined {
    return this.items.find((item) => itemId == item.id);
  }

  add(): void {
    if (this.itemRequirementForm.valid) {
      const itemRequirementAlreadyExistsIndexIndex = this.itemRequirementDtos.findIndex((itemRequirementDto) => itemRequirementDto.itemId == this.itemRequirementForm.value.itemId);
      if (itemRequirementAlreadyExistsIndexIndex > -1)
        this.itemRequirementDtos[itemRequirementAlreadyExistsIndexIndex].quantity += this.itemRequirementForm.value.quantity;
      else
        this.itemRequirementDtos.push(this.itemRequirementForm.value);
      this.itemRequirementForm.reset({itemId: '', quantity: ''});
    }
  }

  removeItemRequirementDto(i: number) {
    this.itemRequirementDtos.splice(i, 1);
  }

  viewUser(user: User): void {
    const modal = this.modalService.open(UserFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.user = user;
    modal.componentInstance.readonly = true;
    modal.componentInstance.openedFromVendor = true;
  }
}
