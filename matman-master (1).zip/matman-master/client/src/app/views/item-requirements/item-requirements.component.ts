import {Component, OnInit, PipeTransform} from '@angular/core';
import {Item, ItemRequirement, User} from "../../model";
import {DecimalPipe} from "@angular/common";
import {SortableTableComponent} from "../../sortable-table.component";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {ItemRequirementService} from "../../service/item-requirement.service";
import {ToastService} from "../../service/toast.service";
import {ItemRequirementFormComponent} from "./item-requirement-form/item-requirement-form.component";
import {environment} from "../../../environments/environment";
import {ItemFormComponent} from "../items/item-form/item-form.component";
import {UserFormComponent} from "../users/user-form/user-form.component";

@Component({
  selector: 'app-item-requirements',
  templateUrl: './item-requirements.component.html',
  styleUrls: ['./item-requirements.component.css'],
  providers: [DecimalPipe]
})
export class ItemRequirementsComponent extends SortableTableComponent<ItemRequirement> implements OnInit {

  constructor(private itemRequirementService: ItemRequirementService, pipe: DecimalPipe, private modalService: NgbModal, private toastService: ToastService) {
    super(pipe);
    this.itemRequirementService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
    });
  }

  search(searchTerm: string, pipe: PipeTransform): ItemRequirement[] {
    return searchTerm === '' ? this.data : this.data.filter(itemRequirement => {
      searchTerm = searchTerm.toLowerCase();
      return (itemRequirement.item.title + itemRequirement.item.description + itemRequirement.item.uom.name + itemRequirement.item.uom.symbol).toLowerCase().includes(searchTerm)
        || pipe.transform(itemRequirement.id).includes(searchTerm);
    }).slice((this.table.page - 1) * this.table.pageSize, (this.table.page - 1) * this.table.pageSize + this.table.pageSize);
  }

  ngOnInit(): void {
  }

  viewItemRequirement(itemRequirement: ItemRequirement): void {
    const modal = this.modalService.open(ItemRequirementFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.itemRequirement = itemRequirement;
    modal.componentInstance.readonly = true;
  }

  openForm(itemRequirement?: ItemRequirement) {
    const modal = this.modalService.open(ItemRequirementFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.itemRequirement = itemRequirement;
    modal.closed.subscribe((formItemRequirements: ItemRequirement[]) => {
      formItemRequirements.forEach((formItemRequirement) => {
        let index = this.data.findIndex(dataItemRequirement => dataItemRequirement.id == formItemRequirement.id);
        if (index === -1) {
          this.data.push(formItemRequirement);
          this.table.collectionSize = this.data.length;
          this.selected = [];
          this.onPageChange();
          this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
        } else {
          this.selected = [];
          this.data[index] = formItemRequirement;
          this.onPageChange();
          this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
        }
      });
    });
  }

  delete(): void {
    this.selected.forEach((itemRequirement) => this.itemRequirementService.delete(itemRequirement.id).subscribe(() => {
        this.data.splice(this.data.indexOf(itemRequirement), 1);
        this.selected.splice(this.selected.indexOf(itemRequirement), 1);
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      })
    );
  }

  refreshData(): void {
    this.itemRequirementService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
      this.toastService.show('Data refreshed', {classname: 'bg-success text-light', delay: 10000});
    }, (error) => this.toastService.show('Could not update Item Requirements. Please try again after sometime.', {
      classname: 'bg-danger',
      delay: environment.toastDisplayTime
    }));
  }

  viewItem(item: Item): void {
    const modal = this.modalService.open(ItemFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.item = item;
    modal.componentInstance.readonly = true;
  }

  viewUser(user: User): void {
    const modal = this.modalService.open(UserFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.user = user;
    modal.componentInstance.readonly = true;
    modal.componentInstance.openedFromVendor = true;
  }

}
