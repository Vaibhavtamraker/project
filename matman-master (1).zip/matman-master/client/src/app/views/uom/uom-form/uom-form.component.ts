import {Component, Input, OnInit} from '@angular/core';
import {Authority, Uom} from "../../../model";
import {FormBuilder, FormGroup} from "@angular/forms";
import {NgbActiveModal, NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {ToastService} from "../../../service/toast.service";
import {ViewComponent} from "../../authority/view/view.component";
import {UomService} from "../../../service/uom.service";

@Component({
  selector: 'app-uom-form',
  templateUrl: './uom-form.component.html',
  styleUrls: ['./uom-form.component.css']
})
export class UomFormComponent implements OnInit {

  @Input() uom: Uom | undefined;
  @Input() readonly : boolean = false;
  uomForm: FormGroup;

  constructor(public activeModal: NgbActiveModal, private uomService: UomService, private fb: FormBuilder, private toastService: ToastService, private modalService: NgbModal) {
    this.uomForm = this.fb.group({
      name: [''],
      symbol: ['']
    });
  }

  ngOnInit(): void {
    if (this.uom) {
      this.uomForm.get('name')?.setValue(this.uom.name);
      this.uomForm.get('symbol')?.setValue(this.uom.symbol);
    }
  }

  onSubmit() {
    if (this.uom)
      this.uomService.update(this.uom.id, this.uomForm.value).subscribe((response) => {
        this.activeModal.close(response);
        this.toastService.show('UOM updated successfully.', {classname: 'bg-success text-light', delay: 10000});
      }, error => {
        this.toastService.show('Could not update UOM. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: 10000
        });
        this.activeModal.dismiss();
      });
    else
      this.uomService.create(this.uomForm.value).subscribe(response => {
        this.activeModal.close(response);
        this.toastService.show('uom created successfully.', {classname: 'bg-success text-light', delay: 10000});
      }, error => {
        this.toastService.show('Could not create new uom. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: 10000
        });
        this.activeModal.dismiss();
      });
  }

}
