import {Component, PipeTransform} from '@angular/core';
import {UomService} from "../../service/uom.service";
import {Uom} from "../../model";
import {DecimalPipe} from "@angular/common";
import {SortableTableComponent} from "../../sortable-table.component";
import {environment} from "../../../environments/environment";
import {ToastService} from "../../service/toast.service";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {UomFormComponent} from "./uom-form/uom-form.component";

@Component({
  selector: 'app-uom',
  templateUrl: './uom.component.html',
  styleUrls: ['./uom.component.css'],
  providers: [DecimalPipe]
})
export class UomComponent extends SortableTableComponent<Uom> {

  constructor(private uomService: UomService, pipe: DecimalPipe, private toastService: ToastService, private modalService: NgbModal) {
    super(pipe);
    this.uomService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
    });
  }

  search(text: string, pipe: PipeTransform): Uom[] {
    return text === '' ? this.data : this.data.filter(country => {
      const term = text.toLowerCase();
      return country.name.toLowerCase().includes(term)
        || pipe.transform(country.id).includes(term)
        || country.symbol.includes(term);
    }).slice((this.table.page - 1) * this.table.pageSize, (this.table.page - 1) * this.table.pageSize + this.table.pageSize);
  }

  refreshData(): void {
    this.uomService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
      this.toastService.show('Data refreshed', {
        classname: 'bg-success text-light',
        delay: environment.toastDisplayTime
      });
    }, (error) => this.toastService.show('Could not update UOMs. Please try again after sometime.' + error.message, {
      classname: 'bg-danger',
      delay: environment.toastDisplayTime
    }));
  }

  viewUom(uom: Uom): void {
    const modal = this.modalService.open(UomFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.uom = uom;
    modal.componentInstance.readonly = true;
  }

  openForm(uom?: Uom) {
    const modal = this.modalService.open(UomFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.uom = uom;
    modal.closed.subscribe(formUom => {
      let index = this.data.findIndex(dataUom => dataUom.id == formUom.id);
      if (index === -1) {
        this.data.push(formUom);
        this.table.collectionSize = this.data.length;
        this.selected = [];
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      } else {
        /*this.data[index] = this.selected[this.selected.findIndex(dataUom => dataUom.id == formUom.id)] = formUom;*/
        this.data[index] = formUom;
        this.selected = [];
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      }
    });
  }

  delete(): void {
    this.selected.forEach((uom) => this.uomService.delete(uom.id).subscribe(() => {
        this.data.splice(this.data.indexOf(uom), 1);
        this.selected.splice(this.selected.indexOf(uom), 1);
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      })
    );
  }
}
