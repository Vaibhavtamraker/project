import {Component, PipeTransform} from '@angular/core';

import {DecimalPipe} from "@angular/common";
import {AuthorityService} from '../../service/authority.service';
import {Authority} from '../../model';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ViewComponent} from './view/view.component';
import {SortableTableComponent} from "../../sortable-table.component";
import {ToastService} from "../../service/toast.service";

@Component({
  selector: 'app-authority',
  templateUrl: './authority.component.html',
  styleUrls: ['./authority.component.css'],
  providers: [DecimalPipe]
})
export class AuthorityComponent extends SortableTableComponent<Authority> {

  constructor(private authorityService: AuthorityService, pipe: DecimalPipe, private modalService: NgbModal, private toastService: ToastService) {
    super(pipe);
    this.authorityService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
    });
  }

  search(text: string, pipe: PipeTransform): Authority[] {
    return this.data.filter(authority => {
      const term = text.toLowerCase();
      return authority.authority.toLowerCase().includes(term)
        || pipe.transform(authority.id).includes(term)
        || authority.description?.includes(term);
    }).slice((this.table.page - 1) * this.table.pageSize, (this.table.page - 1) * this.table.pageSize + this.table.pageSize);
  }

  open(authority: Authority) {
    const model = this.modalService.open(ViewComponent, {ariaLabelledBy: 'modal-basic-title'});
    model.componentInstance.authority = authority;
  }

  refreshData(): void {
    this.authorityService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
      this.toastService.show('Data refreshed', {classname: 'bg-success text-light', delay: 10000});
    }, (error) => this.toastService.show('Could not update authorities. Please try again after sometime.' + error.message, {
      classname: 'bg-danger',
      delay: 10000
    }));
  }

}
