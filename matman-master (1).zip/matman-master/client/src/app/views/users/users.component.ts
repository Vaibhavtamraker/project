import {Component, OnInit, PipeTransform} from '@angular/core';
import {Authority, User} from "../../model";
import {DecimalPipe} from "@angular/common";
import {UserService} from "../../service/user.service";
import {SortableTableComponent} from "../../sortable-table.component";
import {ViewComponent} from "../authority/view/view.component";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {UserFormComponent} from "./user-form/user-form.component";
import {ToastService} from "../../service/toast.service";
import {environment} from "../../../environments/environment";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers: [DecimalPipe]
})
export class UsersComponent extends SortableTableComponent<User> implements OnInit {

  constructor(private userService: UserService, pipe: DecimalPipe, private modalService: NgbModal, private toastService: ToastService) {
    super(pipe);
    this.userService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
    });
  }

  search(searchTerm: string, pipe: PipeTransform): User[] {
    return searchTerm === '' ? this.data : this.data.filter(user => {
      searchTerm = searchTerm.toLowerCase();
      return (user.name.firstName + ' ' + user.name.lastName + user.name.firstName + user.name.lastName + user.mail + user.username + user.mobile).toLowerCase().includes(searchTerm)
        || pipe.transform(user.id).includes(searchTerm);
    }).slice((this.table.page - 1) * this.table.pageSize, (this.table.page - 1) * this.table.pageSize + this.table.pageSize);
  }

  ngOnInit(): void {
  }

  viewAuthority(authority: Authority): void {
    const modal = this.modalService.open(ViewComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.authority = authority;
  }

  viewUser(user: User): void {
    const modal = this.modalService.open(UserFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.user = user;
    modal.componentInstance.readonly = true;
  }

  openForm(user?: User) {
    const modal = this.modalService.open(UserFormComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.user = user;
    modal.closed.subscribe(formUser => {
      let index = this.data.findIndex(dataUser => dataUser.id == formUser.id);
      if (index === -1) {
        this.data.push(formUser);
        this.table.collectionSize = this.data.length;
        this.selected = [];
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      } else {
        /*this.data[index] = this.selected[this.selected.findIndex(dataUser => dataUser.id == formUser.id)] = formUser;*/
        this.selected = [];
        this.data[index] = formUser;
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      }
    });
  }

  delete(): void {
    this.selected.forEach((user) => this.userService.delete(user.id).subscribe(() => {
        this.data.splice(this.data.indexOf(user), 1);
        this.selected.splice(this.selected.indexOf(user), 1);
        this.onPageChange();
        this.onSort({column: this.table.sortColumn, direction: this.table.sortDirection});
      })
    );
  }

  refreshData(): void {
    this.userService.fetchAll().subscribe(response => {
      this.data = response;
      this.table.collectionSize = response.length;
      this.onPageChange();
      this.toastService.show('Data refreshed', {classname: 'bg-success text-light', delay: 10000});
    }, (error) => this.toastService.show('Could not update users. Please try again after sometime.', {
      classname: 'bg-danger',
      delay: environment.toastDisplayTime
    }));
  }
}
