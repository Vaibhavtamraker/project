import {Component, Input, OnInit} from '@angular/core';
import {Authority, User} from "../../../model";
import {NgbActiveModal, NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {AuthorityService} from "../../../service/authority.service";
import {UserService} from "../../../service/user.service";
import {FormBuilder, FormGroup} from "@angular/forms";
import {ToastService} from "../../../service/toast.service";
import {ViewComponent} from "../../authority/view/view.component";


@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {

  @Input() user: User | undefined;
  @Input() readonly: boolean = false;
  @Input() openedFromVendor: boolean = false;
  authorities: Authority[] = [];
  userForm: FormGroup;

  constructor(public activeModal: NgbActiveModal, private authorityService: AuthorityService, private userService: UserService, private fb: FormBuilder, private toastService: ToastService, private modalService: NgbModal) {
    this.authorityService.fetchAll().subscribe(authorities => {
      this.authorities = authorities;
    });
    this.userForm = this.fb.group({
      firstName: [''],
      lastName: [''],
      username: [''],
      mobile: [''],
      mail: [''],
      authorityIds: ['']
    });
  }

  ngOnInit(): void {
    if (this.user) {
      this.userForm.get('firstName')?.setValue(this.user.name.firstName);
      this.userForm.get('lastName')?.setValue(this.user.name.lastName);
      this.userForm.get('username')?.setValue(this.user.username);
      this.userForm.get('mobile')?.setValue(this.user.mobile);
      this.userForm.get('mail')?.setValue(this.user.mail);
      this.userForm.get('authorityIds')?.setValue(this.user.authorities.map(authority => authority.id));
    }
  }

  onSubmit() {
    if (this.user)
      this.userService.update(this.user.id, this.userForm.value).subscribe(response => {
        this.activeModal.close(response);
        this.toastService.show('User updated successfully.', {classname: 'bg-success text-light', delay: 10000});
      }, error => {
        this.toastService.show('Could not update user. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: 10000
        });
        this.activeModal.dismiss();
      });
    else {
      if (this.openedFromVendor)
        this.userForm.get('authorityIds')?.setValue(this.authorities.filter(authority => authority.authority === 'VENDOR').map(authority => authority.id));
      this.userService.create(this.userForm.value).subscribe(response => {
        this.activeModal.close(response);
        this.toastService.show('User created successfully.', {classname: 'bg-success text-light', delay: 10000});
      }, error => {
        this.toastService.show('Could not create new user. Please try again after sometime.' + error.message, {
          classname: 'bg-danger',
          delay: 10000
        });
        this.activeModal.dismiss();
      });
    }
  }

  viewAuthority(authority: Authority): void {
    const modal = this.modalService.open(ViewComponent, {ariaLabelledBy: 'modal-basic-title'});
    modal.componentInstance.authority = authority;
  }
}
