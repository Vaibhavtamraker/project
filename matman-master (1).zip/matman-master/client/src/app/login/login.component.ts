import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, FormControl, Validators, FormArray} from '@angular/forms';
import {AppService} from "../app.service";
import {ActivatedRoute} from "@angular/router";
import {ToastService} from "../service/toast.service";
import {HttpErrorResponse} from "@angular/common/http";


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {

    username: FormControl = new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]);
    password: FormControl = new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]);
    loginForm: FormGroup = new FormGroup({
        username: this.username,
        password: this.password
    });

    constructor(private appService: AppService, private route: ActivatedRoute, private toastService: ToastService) {
    }


    ngOnInit(): void {
    }

    onSubmit() {
        if (this.loginForm.valid) {
            this.appService.authenticate(this.loginForm.value,
                () => {
                    this.toastService.show('Login Successful', {classname: 'bg-success text-light', delay: 10000});
                },
                (errorResponse: HttpErrorResponse) => {
                    this.toastService.show('Login Unsuccessful' + errorResponse.message, {
                        classname: 'bg-danger',
                        delay: 10000
                    });
                });
        }
    }

}

